﻿namespace ProxyApiQualtech.Services.FileWriter
{
    public interface IFileWriter
    {
        void WriteLogFile(string logMessage);
    }
}
